// Default Markdown text as shown in the assignment instructions
var defaultMarkdown = "# This is Slide 01\n" +
"## This is Heading 02 in slide 01\n\n" +
"This is your content on slide 01\n" +
"---\n" +
"# This is Slide 02\n" +
"## This is Heading 02 in slide 02\n\n" +
"This is your content on slide 02\n" +
"---\n" +
"# This is Slide 03\n" +
"## Features of This App\n\n" +
"- Create and Edit slides in real time\n" +
"- Save slides in browser localStorage\n" +
"- Present slides in Full Screen mode";

// Global variables
var currentSlide = 0;
var slidesList = [];
var isPresenting = false;

// Getting HTML elements
var mdEditor = document.getElementById("mdEditor");
var slideContent = document.getElementById("slideContent");
var slideCount = document.getElementById("slideCount");
var leftBtn = document.getElementById("leftBtn");
var rightBtn = document.getElementById("rightBtn");
var fullScreenBtn = document.getElementById("fullScreenBtn");
var saveMsg = document.getElementById("saveMsg");

// Task 8: Load saved slides from browser's internal memory (localStorage) when page opens
window.onload = function () {
    var savedData = localStorage.getItem("myMarkdownSlides");
    if (savedData !== null && savedData !== "") {
        mdEditor.value = savedData;
    } else {
        mdEditor.value = defaultMarkdown;
    }
    updateSlides();
};

// Task 4: Realtime changes when typing in the Markdown editor
mdEditor.addEventListener("input", function () {
    updateSlides();
});

// Split markdown by '---' and show current slide
function updateSlides() {
    var rawText = mdEditor.value;

    // Task 3: Differentiate slides using 3 dashes '---'
    slidesList = rawText.split(/\n---\n|\r\n---\r\n|^---$/m);

    // Keep currentSlide inside valid range
    if (currentSlide >= slidesList.length) {
        currentSlide = slidesList.length - 1;
    }
    if (currentSlide < 0) {
        currentSlide = 0;
    }

    // Convert current slide markdown into HTML
    var currentMd = slidesList[currentSlide];
    slideContent.innerHTML = convertMarkdownToHtml(currentMd);

    // Task 7: Show slide count at the bottom in format: {current slide number} / {total number of slides}
    slideCount.innerText = (currentSlide + 1) + " / " + slidesList.length;

    // Task 5: Disable Left button on first slide, disable Right button on last slide
    if (currentSlide === 0) {
        leftBtn.disabled = true;
    } else {
        leftBtn.disabled = false;
    }

    if (currentSlide === slidesList.length - 1) {
        rightBtn.disabled = true;
    } else {
        rightBtn.disabled = false;
    }
}

// Simple function to convert basic Markdown lines to HTML
function convertMarkdownToHtml(mdText) {
    if (!mdText) {
        return "";
    }

    var lines = mdText.split("\n");
    var html = "";
    var inList = false;

    for (var i = 0; i < lines.length; i++) {
        var line = lines[i].trim();

        if (line === "---") {
            continue;
        }

        // Check for bullet list items
        if (line.indexOf("- ") === 0 || line.indexOf("* ") === 0) {
            if (!inList) {
                html += "<ul>";
                inList = true;
            }
            html += "<li>" + line.substring(2) + "</li>";
            continue;
        } else {
            if (inList) {
                html += "</ul>";
                inList = false;
            }
        }

        // Check for headings and normal text
        if (line.indexOf("### ") === 0) {
            html += "<h3>" + line.substring(4) + "</h3>";
        } else if (line.indexOf("## ") === 0) {
            html += "<h2>" + line.substring(3) + "</h2>";
        } else if (line.indexOf("# ") === 0) {
            html += "<h1>" + line.substring(2) + "</h1>";
        } else if (line !== "") {
            html += "<p>" + line + "</p>";
        }
    }

    if (inList) {
        html += "</ul>";
    }

    return html;
}

// Go to previous slide
function prevSlide() {
    if (currentSlide > 0) {
        currentSlide--;
        updateSlides();
    }
}

// Go to next slide
function nextSlide() {
    if (currentSlide < slidesList.length - 1) {
        currentSlide++;
        updateSlides();
    }
}

// Task 2a: Create new slides
function createNewSlides() {
    var confirmNew = confirm("Do you want to create a new presentation? Unsaved changes will be replaced.");
    if (confirmNew) {
        mdEditor.value = "# New Slide 01\n## Heading 02\n\nWrite your content here...\n---\n# New Slide 02\n## Heading 02\n\nWrite your second slide content here...";
        currentSlide = 0;
        updateSlides();
    }
}

// Load an external .md file if user selects one
function loadMdFile(event) {
    var file = event.target.files[0];
    if (!file) {
        return;
    }
    var reader = new FileReader();
    reader.onload = function (e) {
        mdEditor.value = e.target.result;
        currentSlide = 0;
        updateSlides();
    };
    reader.readAsText(file);
}

// Task 2c & Task 8: Save slides in browser's internal memory (localStorage)
function saveSlides() {
    localStorage.setItem("myMarkdownSlides", mdEditor.value);
    saveMsg.innerText = "Saved!";
    setTimeout(function () {
        saveMsg.innerText = "";
    }, 2000);
}

// Task 2d & Task 5: Toggle Presentation / Full Screen mode
function toggleFullScreen() {
    if (!isPresenting) {
        isPresenting = true;
        document.body.classList.add("presentation-mode");
        fullScreenBtn.innerText = "Exit Full Screen";

        if (document.documentElement.requestFullscreen) {
            document.documentElement.requestFullscreen();
        }
    } else {
        isPresenting = false;
        document.body.classList.remove("presentation-mode");
        fullScreenBtn.innerText = "Full Screen";

        if (document.fullscreenElement && document.exitFullscreen) {
            document.exitFullscreen();
        }
    }
}

// If user exits full screen using Escape key, update button text and layout
document.addEventListener("fullscreenchange", function () {
    if (!document.fullscreenElement && isPresenting) {
        isPresenting = false;
        document.body.classList.remove("presentation-mode");
        fullScreenBtn.innerText = "Full Screen";
    }
});

// Task 6: Keyboard shortcuts (Left Arrow, Right Arrow, F11, Ctrl+S)
document.addEventListener("keydown", function (event) {
    // Ctrl + S to save slides
    if (event.ctrlKey && (event.key === "s" || event.key === "S")) {
        event.preventDefault();
        saveSlides();
        return;
    }

    // F11 to toggle Full Screen / Presentation mode
    if (event.key === "F11") {
        event.preventDefault();
        toggleFullScreen();
        return;
    }

    // Left and Right arrow keys to change slides
    // If user is typing inside the editor and not in presentation mode, only navigate when not editing text cursor,
    // or if editor is not focused
    if (document.activeElement !== mdEditor || isPresenting) {
        if (event.key === "ArrowRight") {
            nextSlide();
        } else if (event.key === "ArrowLeft") {
            prevSlide();
        }
    }
});
